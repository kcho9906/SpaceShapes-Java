package spaceshapes.views;


import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreePath;

import spaceshapes.ShapeModel;
import spaceshapes.ShapeModelEvent;
import spaceshapes.ShapeModelListener;
import spaceshapes.ShapeModelEvent.EventType;

public class Task2 extends Task1 implements ShapeModelListener{
	
	public Task2(ShapeModel model) {
		super(model);
	}

	@Override
	public void update(ShapeModelEvent event) {
		
		Object[] children = {event.operand()};
		int[] childrenIndices = {event.index()};
		TreePath path;
		
		if (event.parent() == null) {
			
			path = new TreePath(event.source().root().path());
		} else {
			path = new TreePath(event.parent().path().toArray());
		
		}
		TreeModelEvent e = new TreeModelEvent(event.source(), path, childrenIndices, children);
		
		for (TreeModelListener listener: _TreeListeners) {
			
			if (event.eventType().equals(EventType.ShapeAdded)) {
				listener.treeNodesInserted(e);
			} else if (event.eventType().equals(EventType.ShapeRemoved) ) {
				listener.treeNodesRemoved(e);
				
			}
		}
		
	}
	
}

