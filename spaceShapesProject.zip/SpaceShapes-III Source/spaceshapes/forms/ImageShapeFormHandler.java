package spaceshapes.forms;





import spaceshapes.CarrierShape;

import spaceshapes.ShapeModel;
import spaceshapes.forms.util.Form;
import spaceshapes.forms.util.FormHandler;
import spaceshapes.forms.util.ProcessFormWorker;

public class ImageShapeFormHandler implements FormHandler {

	private ShapeModel _model;
	private CarrierShape _parentOfNewShape;

	/**
	 * Creates a ImageShapeFormHandler.
	 * 
	 * @param model the ShapeModel to which the handler should add a newly 
	 *        constructed ImageRectangleShape object. 
	 * @param parent the CarrierShape object that will serve as the parent for
	 *        a new ImageRectangleShape instance.
	 */
	public ImageShapeFormHandler(ShapeModel model, CarrierShape parent) {
		_model = model;
		_parentOfNewShape = parent;
	}


	/**
	 * Reads form data that describes an ImageRectangleShape. Based on the 
	 * data, this SimpleImageShapeFormHandler creates a new ImageRectangleShape 
	 * object, adds it to a ShapeModel and to a CarrierShape within the model.
	 * 
	 * @param form the Form that contains the ImageRectangleShape data.
	 */
	@Override
	public void processForm(Form form) {
		
		ProcessFormWorker worker = new ProcessFormWorker(form, _model, _parentOfNewShape);
		worker.execute();

	}
}


