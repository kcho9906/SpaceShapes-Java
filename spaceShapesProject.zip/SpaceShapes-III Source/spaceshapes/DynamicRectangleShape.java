package spaceshapes;

import java.awt.Color;

/**
 * Class to represent a simple oval space-shape.
 */

public class DynamicRectangleShape extends Shape {

	protected boolean _filled;
	protected Color _color = Color.white;
	protected final Color _defaultColor = Color.white;
	
	/**
	 * Default constructor that creates a OvalShape instance whose instance
	 * variables are set to default values.
	 */
	
	public DynamicRectangleShape() {
		super();
	}
	/**
	 * Creates a DynamicShape instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed and direction for horizontal axis.
	 * @param deltaY speed and direction for vertical axis.
	 */
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY) {
		super(x,y,deltaX,deltaY);
	}

	/**
	 * Creates a DynamicShape instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param color color of DynamicShape
	 */
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, Color color) {
		super(x,y,deltaX, deltaY);
		_color = color;
		
	}
	
	/**
	 * Creates a DynamicShape instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 */
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, int width, int height) {
		super(x,y,deltaX,deltaY,width,height);
	}


	/**
	 * Creates a DynamicShape instance with specified values for instance 
	 * variables.
	 * @param x x position.
	 * @param y y position.
	 * @param deltaX speed (pixels per move call) and direction for horizontal 
	 *        axis.
	 * @param deltaY speed (pixels per move call) and direction for vertical 
	 *        axis.
	 * @param width width in pixels.
	 * @param height height in pixels.
	 * @param color color of DynamicShape
	 */
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, int width, int height, Color color) {
		super(x,y,deltaX,deltaY,width,height);
		_color = color;
	}
	
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, int width, int height, String text) {
		super(x, y, deltaX, deltaY, width, height, text);
	
	}
	
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, int width, int height, String text, Color colour) {
		super(x, y, deltaX, deltaY, width, height, text);
		_color = colour;
	
	}
	
	@Override
	public void move(int width, int height) {
		super.move(width, height);
	
		if (_y <= 0 || _y + _height >= height) {
			_filled = false;
		}
		
		if ( _x <= 0 || _x + _width >= width) {
			_filled = true;
			
		}

		
		
	}

	/**
	 * Paints this DynamicShape object using the supplied Painter object.
	 */
	public void doPaint( Painter painter ) {
		
		if( _filled ) {
			
			painter.setColor(_color);
			painter.fillRect(_x, _y, _width, _height);
			//restore original colour
			painter.setColor(_defaultColor);
			
		} else {
			painter.drawRect(_x, _y, _width, _height);
		}
	}

}
