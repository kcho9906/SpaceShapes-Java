package spaceshapes;

import java.awt.Color;
import java.awt.Image;



/** 
 * Interface to represent a type that offers primitive drawing methods.
 * 
 * @author Steven Ho (Original Author - Ian Warren)
 * 
 */
public interface Painter {
	/**
	 * Draws a rectangle. Parameters x and y specify the top left corner of the
	 * oval. Parameters width and height specify its width and height.
	 */
	public void drawRect(int x, int y, int width, int height);
	
	/**
	 * Draws an oval. Parameters x and y specify the top left corner of the
	 * oval. Parameters width and height specify its width and height.
	 */
	public void drawOval(int x, int y, int width, int height);
	
	/**
	 * Draws a line. Parameters x1 and y1 specify the starting point of the 
	 * line, parameters x2 and y2 the ending point.
	 */
	public void drawLine(int x1, int y1, int x2, int y2);

	/**
	 * Draws a Hexagon with width greater or equal to 40 pixels.
	 * @param x	top left corner x co-ordinate.
	 * @param y top left corner y co-ordinate.
	 * @param width	width of hexagon side
	 * @param height height of hexagon
	 */
	public void drawHexagon(int x, int y, int width, int height);


	/**
	 * Draws a Hexagon with width less than 40
	 * @param x	top left corner x co-ordinate.
	 * @param y top left corner y co-ordinate.
	 * @param width	width of hexagon side
	 * @param height height of hexagon
	 */
	public void drawDiamond(int x, int y, int width, int height);
	
	/**
	 * Draws a filled in rectangle
	 * @param x top left corner x co-ordinate.
	 * @param y top left corner y co-ordinate.
	 * @param width width of rectangle
	 * @param height height of rectangle
	 */
	public void fillRect(int x, int y, int width, int height);
	
	/**
	 * gets preset colour provided.
	 */
	public Color getColor();
	
	/**
	 * set colour to specified color
	 * @param color color to be changed to 
	 */
	public void setColor(Color color);

	public void translate(int _x, int _y);
	
	public void drawCentredText(String text, int x, int y, int width, int height);

	public void drawImage(Image _picture, int x, int y, int width, int height);
	
	
}
